package com.smartgrocerylist.springboot;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SmartGroceryListApplication {

	public static void main(String[] args) {
		SpringApplication.run(SmartGroceryListApplication.class, args);
	}

}
